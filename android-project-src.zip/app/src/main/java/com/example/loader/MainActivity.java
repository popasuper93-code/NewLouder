package com.example.loader;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * Экран активации лицензии и загрузки нативного плагина.
 *
 * Важно понимать границы этой защиты:
 * - Проверка подписи и обфускация ProGuard/R8 усложняют модификацию APK,
 *   но не делают её невозможной (кто угодно с root/Frida может это обойти).
 * - Единственный источник истины — сервер. Клиентские проверки лишь поднимают
 *   порог для обычного пользователя, не обладающего навыками реверс-инжиниринга.
 * - Проверка SHA-256 скачанного .so обязательна: сервер не только
 *   аутентифицирует запрос, но и защищает от подмены файла по пути (MITM),
 *   даже с учётом использования HTTPS "defense in depth".
 */
public class MainActivity extends AppCompatActivity {

    // ---------------------------------------------------------------
    // Конфигурация — замените под свой проект
    // ---------------------------------------------------------------

    // Тестовый сервер — см. предупреждение в README про HTTP без TLS.
    private static final String BASE_URL = "http://78.154.103.44:9653";
    private static final String AUTH_URL = BASE_URL + "/api/auth";

    // SHA-256 отпечаток сертификата подписи РЕЛИЗНОЙ сборки (hex, uppercase, без двоеточий).
    // Получить: keytool -printcert -jarfile app-release.apk  (или через `apksigner`)
    // и преобразовать вывод в hex-строку без разделителей.
    private static final String EXPECTED_SIGNATURE_SHA256 =
            "PUT_YOUR_RELEASE_CERTIFICATE_SHA256_HERE";

    private static final String PREFS_NAME = "license_prefs";
    private static final String PREF_KEY = "license_key";
    private static final String PLUGIN_FILE_NAME = "plugin.so";

    // ---------------------------------------------------------------

    private EditText keyInput;
    private Button activateButton;
    private Button loadButton;
    private View keyEntryGroup;
    private View readyGroup;
    private ProgressBar progressBar;
    private TextView statusText;

    private final OkHttpClient httpClient = new OkHttpClient();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1) Проверка подписи — до любой другой логики.
        // ВРЕМЕННО ОТКЛЮЧЕНО для debug-сборки через GitHub Actions: EXPECTED_SIGNATURE_SHA256
        // ниже — заглушка, debug-сборка подписана тестовым ключом Android и никогда её не пройдёт.
        // Когда сделаешь свою релизную подписанную сборку — узнаешь реальный SHA-256 сертификата
        // (см. README.md, раздел "Сборка Android-приложения") и раскомментируешь строку ниже.
        // verifyAppSignatureOrDie();

        // 2) Защита от скриншотов/записи экрана до отрисовки контента.
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
        );

        setContentView(R.layout.activity_main);

        keyInput = findViewById(R.id.keyInput);
        activateButton = findViewById(R.id.activateButton);
        loadButton = findViewById(R.id.loadButton);
        keyEntryGroup = findViewById(R.id.keyEntryGroup);
        readyGroup = findViewById(R.id.readyGroup);
        progressBar = findViewById(R.id.progressBar);
        statusText = findViewById(R.id.statusText);

        activateButton.setOnClickListener(v -> {
            String key = keyInput.getText().toString().trim();
            if (TextUtils.isEmpty(key)) {
                Toast.makeText(this, "Введите ключ", Toast.LENGTH_SHORT).show();
                return;
            }
            activate(key, true);
        });

        loadButton.setOnClickListener(v -> loadPluginIntoProcess());

        // Если плагин уже скачан и ключ сохранён — сразу показываем экран "готово".
        File existingPlugin = new File(getFilesDir(), PLUGIN_FILE_NAME);
        String savedKey = getSavedKey();
        if (existingPlugin.exists() && !TextUtils.isEmpty(savedKey)) {
            showReadyState("Модуль уже загружен ранее");
        } else if (!TextUtils.isEmpty(savedKey)) {
            // Ключ есть, файла нет — пробуем автоматически реактивировать.
            keyInput.setText(savedKey);
            activate(savedKey, false);
        }
    }

    // =================================================================
    // Проверка подписи приложения
    // =================================================================

    private void verifyAppSignatureOrDie() {
        String actual = getSigningCertificateSha256();
        if (actual == null || !actual.equalsIgnoreCase(EXPECTED_SIGNATURE_SHA256)) {
            // Намеренно жёсткое завершение процесса без дополнительной информации
            // в логах релизной сборки (см. proguard-rules.pro — Log.* вырезается).
            Process.killProcess(Process.myPid());
            System.exit(1);
        }
    }

    @Nullable
    private String getSigningCertificateSha256() {
        try {
            PackageManager pm = getPackageManager();
            String packageName = getPackageName();

            Signature[] signatures;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                PackageInfo info = pm.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES);
                SigningInfo signingInfo = info.signingInfo;
                if (signingInfo == null) return null;
                signatures = signingInfo.hasMultipleSigners()
                        ? signingInfo.getApkContentsSigners()
                        : signingInfo.getSigningCertificateHistory();
            } else {
                @SuppressWarnings("deprecation")
                PackageInfo info = pm.getPackageInfo(packageName, PackageManager.GET_SIGNATURES);
                @SuppressWarnings("deprecation")
                Signature[] sigs = info.signatures;
                signatures = sigs;
            }

            if (signatures == null || signatures.length == 0) return null;

            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(signatures[0].toByteArray());
            return bytesToHex(hash);
        } catch (PackageManager.NameNotFoundException | NoSuchAlgorithmException e) {
            return null;
        }
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format(Locale.US, "%02X", b));
        }
        return sb.toString();
    }

    // =================================================================
    // Активация ключа и загрузка плагина
    // =================================================================

    // Поля, в которых может приходить ссылка на файл — проверяются по порядку.
    // Подтверждено по /docs сервера: AuthResponse.download_url.
    private static final String[] URL_FIELD_CANDIDATES = {"download_url", "url", "link"};
    // Поля, в которых может приходить текст ошибки.
    // Подтверждено по /docs сервера: ErrorResponse.reason (403); detail/message оставлены
    // как запасной вариант на случай другого формата ответа (например от самого FastAPI).
    private static final String[] ERROR_FIELD_CANDIDATES = {"reason", "detail", "message"};
    // Поля, в которых может приходить контрольная сумма файла (необязательно).
    private static final String[] HASH_FIELD_CANDIDATES = {"plugin_sha256", "sha256", "hash"};

    private void activate(String licenseKey, boolean showErrors) {
        setBusy(true, "Проверка ключа...");

        JSONObject body = new JSONObject();
        try {
            // Подтверждено по /docs сервера: AuthRequest.license_key (4..128 символов).
            body.put("license_key", licenseKey);
        } catch (JSONException e) {
            setBusy(false, "Внутренняя ошибка");
            return;
        }

        RequestBody requestBody = RequestBody.create(
                body.toString(), MediaType.get("application/json; charset=utf-8"));

        Request request = new Request.Builder()
                .url(AUTH_URL)
                .post(requestBody)
                .build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUi(() -> {
                    setBusy(false, null);
                    if (showErrors) {
                        showError("Нет соединения с сервером");
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) {
                try (ResponseBody respBody = response.body()) {
                    String raw = respBody != null ? respBody.string() : "";

                    if (!response.isSuccessful()) {
                        String reason = extractFirstField(raw, ERROR_FIELD_CANDIDATES,
                                "Ключ отклонён сервером (код " + response.code() + ")");
                        runOnUi(() -> {
                            setBusy(false, null);
                            showError(reason);
                        });
                        return;
                    }

                    JSONObject json;
                    try {
                        json = new JSONObject(raw);
                    } catch (JSONException e) {
                        runOnUi(() -> {
                            setBusy(false, null);
                            showError("Сервер вернул не-JSON ответ");
                        });
                        return;
                    }

                    String downloadUrl = firstNonEmpty(json, URL_FIELD_CANDIDATES);
                    if (downloadUrl == null) {
                        runOnUi(() -> {
                            setBusy(false, null);
                            showError("В ответе сервера нет ссылки на файл (ожидались поля: "
                                    + TextUtils.join(", ", URL_FIELD_CANDIDATES) + ")");
                        });
                        return;
                    }

                    // Сервер может не отдавать хеш вовсе — тогда проверка целостности
                    // просто пропускается (хуже, чем с хешем, но лучше честно, чем падать).
                    String expectedSha256 = firstNonEmpty(json, HASH_FIELD_CANDIDATES);

                    // Ключ принят сервером — сохраняем для последующих запусков.
                    saveKey(licenseKey);

                    String finalDownloadUrl = resolveUrl(downloadUrl);
                    runOnUi(() -> setStatus("Ключ принят, загрузка модуля..."));
                    downloadPlugin(finalDownloadUrl, expectedSha256);

                } catch (IOException e) {
                    runOnUi(() -> {
                        setBusy(false, null);
                        showError("Ошибка чтения ответа сервера");
                    });
                }
            }
        });
    }

    /** Если сервер вернул относительный путь (например "/api/download?token=..."), достраиваем базовый URL. */
    private String resolveUrl(String maybeRelative) {
        if (maybeRelative.startsWith("http://") || maybeRelative.startsWith("https://")) {
            return maybeRelative;
        }
        if (!maybeRelative.startsWith("/")) {
            maybeRelative = "/" + maybeRelative;
        }
        return BASE_URL + maybeRelative;
    }

    /** Возвращает значение первого найденного непустого строкового поля из списка кандидатов. */
    @Nullable
    private static String firstNonEmpty(JSONObject json, String[] candidates) {
        for (String field : candidates) {
            if (json.has(field) && !json.isNull(field)) {
                String value = json.optString(field, "");
                if (!TextUtils.isEmpty(value)) {
                    return value;
                }
            }
        }
        return null;
    }

    private static String extractFirstField(String rawBody, String[] candidates, String fallback) {
        try {
            JSONObject json = new JSONObject(rawBody);
            String value = firstNonEmpty(json, candidates);
            if (value != null) return value;
        } catch (JSONException ignored) {
        }
        return fallback;
    }

    private void showError(String message) {
        setStatus(message);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void downloadPlugin(String url, @Nullable String expectedSha256) {
        Request request = new Request.Builder().url(url).get().build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUi(() -> {
                    setBusy(false, null);
                    setStatus("Ошибка загрузки модуля");
                });
            }

            @Override
            public void onResponse(Call call, Response response) {
                if (!response.isSuccessful() || response.body() == null) {
                    runOnUi(() -> {
                        setBusy(false, null);
                        setStatus("Сервер не отдал файл модуля");
                    });
                    return;
                }

                File tmpFile = new File(getCacheDir(), PLUGIN_FILE_NAME + ".tmp");
                try (InputStream in = response.body().byteStream();
                     FileOutputStream out = new FileOutputStream(tmpFile)) {

                    byte[] buffer = new byte[8192];
                    int read;
                    while ((read = in.read(buffer)) != -1) {
                        out.write(buffer, 0, read);
                    }
                } catch (IOException e) {
                    runOnUi(() -> {
                        setBusy(false, null);
                        setStatus("Ошибка сохранения файла");
                    });
                    return;
                }

                // Если сервер прислал хеш — файл обязан ему соответствовать.
                // Если не прислал — пропускаем проверку, но честно предупреждаем об этом в статусе
                // (тестовый сервер; для прод-версии хеш должен быть обязательным полем ответа).
                boolean hashVerified = false;
                if (!TextUtils.isEmpty(expectedSha256)) {
                    String actualSha256 = sha256OfFile(tmpFile);
                    if (actualSha256 == null || !actualSha256.equalsIgnoreCase(expectedSha256)) {
                        //noinspection ResultOfMethodCallIgnored
                        tmpFile.delete();
                        runOnUi(() -> {
                            setBusy(false, null);
                            showError("Контрольная сумма модуля не совпадает — файл отклонён");
                        });
                        return;
                    }
                    hashVerified = true;
                }
                final boolean finalHashVerified = hashVerified;

                File finalFile = new File(getFilesDir(), PLUGIN_FILE_NAME);
                if (finalFile.exists()) {
                    //noinspection ResultOfMethodCallIgnored
                    finalFile.delete();
                }
                boolean moved = tmpFile.renameTo(finalFile);

                runOnUi(() -> {
                    setBusy(false, null);
                    if (moved) {
                        showReadyState(finalHashVerified
                                ? "Модуль загружен и проверен по хешу"
                                : "Модуль загружен (сервер не прислал хеш — целостность не проверена)");
                    } else {
                        showError("Не удалось сохранить файл модуля");
                    }
                });
            }
        });
    }

    @Nullable
    private String sha256OfFile(File file) {
        try (FileInputStream fis = new FileInputStream(file)) {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[8192];
            int read;
            while ((read = fis.read(buffer)) != -1) {
                digest.update(buffer, 0, read);
            }
            return bytesToHex(digest.digest());
        } catch (IOException | NoSuchAlgorithmException e) {
            return null;
        }
    }

    private void loadPluginIntoProcess() {
        File pluginFile = new File(getFilesDir(), PLUGIN_FILE_NAME);
        if (!pluginFile.exists()) {
            setStatus("Файл модуля отсутствует, активируйте ключ заново");
            return;
        }
        try {
            System.load(pluginFile.getAbsolutePath());
            setStatus("Модуль загружен в процесс");
            Toast.makeText(this, "Готово к работе", Toast.LENGTH_SHORT).show();
        } catch (UnsatisfiedLinkError e) {
            setStatus("Не удалось загрузить модуль: " + e.getMessage());
        }
    }

    // =================================================================
    // SharedPreferences
    // =================================================================

    private void saveKey(String key) {
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(PREF_KEY, key)
                .apply();
    }

    @Nullable
    private String getSavedKey() {
        return getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getString(PREF_KEY, null);
    }

    // =================================================================
    // UI helpers
    // =================================================================

    private void runOnUi(Runnable r) {
        mainHandler.post(r);
    }

    private void setBusy(boolean busy, @Nullable String status) {
        progressBar.setVisibility(busy ? View.VISIBLE : View.GONE);
        activateButton.setEnabled(!busy);
        if (status != null) {
            setStatus(status);
        }
    }

    private void setStatus(String text) {
        statusText.setText(text);
    }

    private void showReadyState(String status) {
        keyEntryGroup.setVisibility(View.GONE);
        readyGroup.setVisibility(View.VISIBLE);
        setStatus(status);
    }
}
