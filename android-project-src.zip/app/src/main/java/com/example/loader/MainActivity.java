package com.example.loader;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * Лоудер собственного native-плагина приложения.
 *
 * Поток:
 *   1) Экран входа — ключ проверяется на сервере, сохраняется в SharedPreferences.
 *   2) Главный экран — кнопка "Загрузить модуль" повторно проверяет ключ на сервере
 *      (защита от локальной подмены состояния "залогинен"), затем скачивает .so
 *      в getFilesDir(), проверяет его SHA-256 (если сервер его прислал) и даёт
 *      кнопку "Запустить" (System.load()).
 *   3) Настройки — звук кликов (SoundPool) и акцентный цвет интерфейса.
 *
 * Границы защиты (см. предыдущие обсуждения): проверка подписи и обфускация
 * усложняют модификацию APK обычным пользователем, но не останавливают того,
 * кто патчит байткод напрямую. Единственный источник истины — сервер.
 */
public class MainActivity extends AppCompatActivity {

    // ---------------------------------------------------------------
    // Конфигурация
    // ---------------------------------------------------------------

    private static final String AUTH_URL = BuildConfig.SERVER_BASE_URL + "/api/auth";
    private static final String BASE_URL = BuildConfig.SERVER_BASE_URL;

    // SHA-256 отпечаток сертификата подписи РЕЛИЗНОЙ сборки (hex, uppercase, без двоеточий).
    private static final String EXPECTED_SIGNATURE_SHA256 =
            "PUT_YOUR_RELEASE_CERTIFICATE_SHA256_HERE";

    private static final String PREFS_NAME = "loader_prefs";
    private static final String PREF_KEY = "license_key";
    private static final String PREF_SOUND_ENABLED = "sound_enabled";
    private static final String PREF_ACCENT_COLOR = "accent_color";
    private static final String PLUGIN_FILE_NAME = "plugin.so";

    // Поля ответа сервера — подтверждены через /docs конкретного сервера.
    private static final String[] URL_FIELD_CANDIDATES = {"download_url", "url", "link"};
    private static final String[] ERROR_FIELD_CANDIDATES = {"reason", "detail", "message"};
    private static final String[] HASH_FIELD_CANDIDATES = {"plugin_sha256", "sha256", "hash"};

    // Палитра акцентных цветов для настроек.
    private static final int[] ACCENT_COLORS = {
            0xFF00C9A7, // бирюзовый (по умолчанию)
            0xFF7C5CFF, // фиолетовый
            0xFF4DA6FF, // синий
            0xFFFF8A5B, // оранжевый
    };

    // ---------------------------------------------------------------

    private EditText keyInput;
    private Button loginButton;
    private ProgressBar loginProgress;
    private TextView loginStatus;

    private View loginGroup;
    private View appGroup;
    private View mainScreenGroup;
    private View settingsScreenGroup;

    private TextView logText;
    private ScrollView logScroll;
    private Button loadModuleButton;
    private Button launchButton;
    private ProgressBar mainProgress;

    private Button navHomeButton;
    private Button navSettingsButton;
    private Switch soundSwitch;
    private LinearLayout accentSwatchRow;

    private final OkHttpClient httpClient = new OkHttpClient();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final SimpleDateFormat logTimeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());

    private SoundPool soundPool;
    private int clickSoundId = -1;
    private boolean soundLoaded = false;
    private boolean soundEnabled = true;
    private int accentColor = ACCENT_COLORS[0];

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        verifyAppSignatureOrDie();

        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
        );

        setContentView(R.layout.activity_main);
        bindViews();
        loadPreferences();
        setupSoundPool();
        buildAccentSwatches();
        applyAccentColor();
        wireListeners();

        String savedKey = getSavedKey();
        if (!TextUtils.isEmpty(savedKey)) {
            keyInput.setText(savedKey);
            showApp(false);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (soundPool != null) {
            soundPool.release();
            soundPool = null;
        }
    }

    private void bindViews() {
        loginGroup = findViewById(R.id.loginGroup);
        appGroup = findViewById(R.id.appGroup);
        mainScreenGroup = findViewById(R.id.mainScreenGroup);
        settingsScreenGroup = findViewById(R.id.settingsScreenGroup);

        keyInput = findViewById(R.id.keyInput);
        loginButton = findViewById(R.id.loginButton);
        loginProgress = findViewById(R.id.loginProgress);
        loginStatus = findViewById(R.id.loginStatus);

        logText = findViewById(R.id.logText);
        logScroll = findViewById(R.id.logScroll);
        loadModuleButton = findViewById(R.id.loadModuleButton);
        launchButton = findViewById(R.id.launchButton);
        mainProgress = findViewById(R.id.mainProgress);

        navHomeButton = findViewById(R.id.navHomeButton);
        navSettingsButton = findViewById(R.id.navSettingsButton);
        soundSwitch = findViewById(R.id.soundSwitch);
        accentSwatchRow = findViewById(R.id.accentSwatchRow);
    }

    private void wireListeners() {
        loginButton.setOnClickListener(v -> {
            playClick();
            String key = keyInput.getText().toString().trim();
            if (TextUtils.isEmpty(key)) {
                Toast.makeText(this, "Введите ключ", Toast.LENGTH_SHORT).show();
                return;
            }
            login(key);
        });

        loadModuleButton.setOnClickListener(v -> {
            playClick();
            loadModuleFlow();
        });

        launchButton.setOnClickListener(v -> {
            playClick();
            launchModule();
        });

        navHomeButton.setOnClickListener(v -> {
            playClick();
            switchTab(true);
        });

        navSettingsButton.setOnClickListener(v -> {
            playClick();
            switchTab(false);
        });

        soundSwitch.setOnCheckedChangeListener((btn, checked) -> {
            soundEnabled = checked;
            getPrefs().edit().putBoolean(PREF_SOUND_ENABLED, checked).apply();
            if (checked) playClick();
        });
    }

    // =================================================================
    // Вход
    // =================================================================

    private void login(String licenseKey) {
        setLoginBusy(true);
        appendLog("Запрос на сервер...");

        postAuth(licenseKey, new AuthCallback() {
            @Override
            public void onValid(String downloadUrl, @Nullable String sha256) {
                saveKey(licenseKey);
                appendLog("Ключ верный");
                runOnUi(() -> {
                    setLoginBusy(false);
                    showApp(true);
                });
            }

            @Override
            public void onRejected(String reason) {
                runOnUi(() -> {
                    setLoginBusy(false);
                    loginStatus.setText(reason);
                    Toast.makeText(MainActivity.this, reason, Toast.LENGTH_LONG).show();
                });
            }

            @Override
            public void onNetworkError() {
                runOnUi(() -> {
                    setLoginBusy(false);
                    loginStatus.setText("Нет соединения с сервером");
                });
            }
        });
    }

    private void setLoginBusy(boolean busy) {
        loginProgress.setVisibility(busy ? View.VISIBLE : View.GONE);
        loginButton.setEnabled(!busy);
    }

    private void showApp(boolean animate) {
        if (animate) {
            loginGroup.animate().alpha(0f).setDuration(200)
                    .setInterpolator(new AccelerateDecelerateInterpolator())
                    .withEndAction(() -> {
                        loginGroup.setVisibility(View.GONE);
                        loginGroup.setAlpha(1f);
                        appGroup.setAlpha(0f);
                        appGroup.setVisibility(View.VISIBLE);
                        appGroup.animate().alpha(1f).setDuration(220).start();
                    }).start();
        } else {
            loginGroup.setVisibility(View.GONE);
            appGroup.setVisibility(View.VISIBLE);
        }
        switchTab(true);
    }

    private void switchTab(boolean toHome) {
        if (toHome) {
            crossfade(settingsScreenGroup, mainScreenGroup);
            navHomeButton.setTextColor(0xFFFFFFFF);
            navSettingsButton.setTextColor(0xFF9FB3BA);
        } else {
            crossfade(mainScreenGroup, settingsScreenGroup);
            navHomeButton.setTextColor(0xFF9FB3BA);
            navSettingsButton.setTextColor(0xFFFFFFFF);
        }
    }

    private void crossfade(View out, View in) {
        if (in.getVisibility() == View.VISIBLE) return;
        out.animate().alpha(0f).setDuration(150).withEndAction(() -> {
            out.setVisibility(View.GONE);
            out.setAlpha(1f);
            in.setAlpha(0f);
            in.setVisibility(View.VISIBLE);
            in.animate().alpha(1f).setDuration(180).start();
        }).start();
    }

    // =================================================================
    // Загрузка модуля
    // =================================================================

    private void loadModuleFlow() {
        String key = getSavedKey();
        if (TextUtils.isEmpty(key)) {
            appendLog("Ошибка: ключ не найден, повторите вход");
            return;
        }

        setMainBusy(true);
        appendLog("Повторная проверка ключа...");

        postAuth(key, new AuthCallback() {
            @Override
            public void onValid(String downloadUrl, @Nullable String sha256) {
                appendLog("Ключ верный, скачивание...");
                downloadPlugin(downloadUrl, sha256);
            }

            @Override
            public void onRejected(String reason) {
                runOnUi(() -> {
                    setMainBusy(false);
                    appendLog("Ошибка: " + reason);
                    Toast.makeText(MainActivity.this, reason, Toast.LENGTH_LONG).show();
                });
            }

            @Override
            public void onNetworkError() {
                runOnUi(() -> {
                    setMainBusy(false);
                    appendLog("Ошибка: нет соединения с сервером");
                });
            }
        });
    }

    private void downloadPlugin(String url, @Nullable String expectedSha256) {
        Request request = new Request.Builder().url(resolveUrl(url)).get().build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUi(() -> {
                    setMainBusy(false);
                    appendLog("Ошибка загрузки модуля");
                });
            }

            @Override
            public void onResponse(Call call, Response response) {
                if (!response.isSuccessful() || response.body() == null) {
                    runOnUi(() -> {
                        setMainBusy(false);
                        appendLog("Сервер не отдал файл модуля");
                    });
                    return;
                }

                File tmpFile = new File(getCacheDir(), PLUGIN_FILE_NAME + ".tmp");
                try (InputStream in = response.body().byteStream();
                     FileOutputStream out = new FileOutputStream(tmpFile)) {
                    byte[] buffer = new byte[8192];
                    int read;
                    while ((read = in.read(buffer)) != -1) {
                        out.write(buffer, 0, read);
                    }
                } catch (IOException e) {
                    runOnUi(() -> {
                        setMainBusy(false);
                        appendLog("Ошибка сохранения файла");
                    });
                    return;
                }

                boolean hashVerified = false;
                if (!TextUtils.isEmpty(expectedSha256)) {
                    String actual = sha256OfFile(tmpFile);
                    if (actual == null || !actual.equalsIgnoreCase(expectedSha256)) {
                        //noinspection ResultOfMethodCallIgnored
                        tmpFile.delete();
                        runOnUi(() -> {
                            setMainBusy(false);
                            appendLog("Контрольная сумма не совпадает — файл отклонён");
                        });
                        return;
                    }
                    hashVerified = true;
                }
                final boolean finalHashVerified = hashVerified;

                File finalFile = new File(getFilesDir(), PLUGIN_FILE_NAME);
                if (finalFile.exists()) {
                    //noinspection ResultOfMethodCallIgnored
                    finalFile.delete();
                }
                boolean moved = tmpFile.renameTo(finalFile);

                runOnUi(() -> {
                    setMainBusy(false);
                    if (moved) {
                        appendLog(finalHashVerified
                                ? "Готово (целостность проверена)"
                                : "Готово (сервер не прислал хеш — проверка пропущена)");
                        Toast.makeText(MainActivity.this, "Готово! Модуль загружен", Toast.LENGTH_SHORT).show();
                        launchButton.setVisibility(View.VISIBLE);
                        launchButton.setAlpha(0f);
                        launchButton.animate().alpha(1f).setDuration(200).start();
                    } else {
                        appendLog("Не удалось сохранить файл модуля");
                    }
                });
            }
        });
    }

    private void launchModule() {
        File pluginFile = new File(getFilesDir(), PLUGIN_FILE_NAME);
        if (!pluginFile.exists()) {
            appendLog("Файл модуля отсутствует");
            return;
        }
        try {
            System.load(pluginFile.getAbsolutePath());
            appendLog("Модуль запущен в процессе");
            Toast.makeText(this, "Готово к работе", Toast.LENGTH_SHORT).show();
        } catch (UnsatisfiedLinkError e) {
            appendLog("Не удалось запустить модуль: " + e.getMessage());
        }
    }

    private void setMainBusy(boolean busy) {
        mainProgress.setVisibility(busy ? View.VISIBLE : View.GONE);
        loadModuleButton.setEnabled(!busy);
    }

    private String resolveUrl(String maybeRelative) {
        if (maybeRelative.startsWith("http://") || maybeRelative.startsWith("https://")) {
            return maybeRelative;
        }
        String path = maybeRelative.startsWith("/") ? maybeRelative : "/" + maybeRelative;
        return BASE_URL + path;
    }

    // =================================================================
    // Сетевой слой: общий POST /api/auth
    // =================================================================

    private interface AuthCallback {
        void onValid(String downloadUrl, @Nullable String sha256);
        void onRejected(String reason);
        void onNetworkError();
    }

    private void postAuth(String licenseKey, AuthCallback callback) {
        JSONObject body = new JSONObject();
        try {
            body.put("license_key", licenseKey);
        } catch (JSONException e) {
            callback.onRejected("Внутренняя ошибка");
            return;
        }

        RequestBody requestBody = RequestBody.create(
                body.toString(), MediaType.get("application/json; charset=utf-8"));
        Request request = new Request.Builder().url(AUTH_URL).post(requestBody).build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                callback.onNetworkError();
            }

            @Override
            public void onResponse(Call call, Response response) {
                try (ResponseBody respBody = response.body()) {
                    String raw = respBody != null ? respBody.string() : "";

                    if (!response.isSuccessful()) {
                        String reason = extractFirstField(raw, ERROR_FIELD_CANDIDATES,
                                "Ключ отклонён сервером (код " + response.code() + ")");
                        callback.onRejected(reason);
                        return;
                    }

                    JSONObject json;
                    try {
                        json = new JSONObject(raw);
                    } catch (JSONException e) {
                        callback.onRejected("Сервер вернул не-JSON ответ");
                        return;
                    }

                    String downloadUrl = firstNonEmpty(json, URL_FIELD_CANDIDATES);
                    if (downloadUrl == null) {
                        callback.onRejected("В ответе сервера нет ссылки на файл");
                        return;
                    }
                    String hash = firstNonEmpty(json, HASH_FIELD_CANDIDATES);
                    callback.onValid(downloadUrl, hash);

                } catch (IOException e) {
                    callback.onRejected("Ошибка чтения ответа сервера");
                }
            }
        });
    }

    @Nullable
    private static String firstNonEmpty(JSONObject json, String[] candidates) {
        for (String field : candidates) {
            if (json.has(field) && !json.isNull(field)) {
                String value = json.optString(field, "");
                if (!TextUtils.isEmpty(value)) return value;
            }
        }
        return null;
    }

    private static String extractFirstField(String rawBody, String[] candidates, String fallback) {
        try {
            JSONObject json = new JSONObject(rawBody);
            String value = firstNonEmpty(json, candidates);
            if (value != null) return value;
        } catch (JSONException ignored) {
        }
        return fallback;
    }

    // =================================================================
    // Журнал действий
    // =================================================================

    private void appendLog(String message) {
        runOnUi(() -> {
            String time = logTimeFormat.format(new Date());
            String line = "[" + time + "] " + message + "\n";
            logText.append(line);
            logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
        });
    }

    // =================================================================
    // Звук кликов (SoundPool)
    // =================================================================

    private void setupSoundPool() {
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        soundPool = new SoundPool.Builder()
                .setMaxStreams(2)
                .setAudioAttributes(attrs)
                .build();
        soundPool.setOnLoadCompleteListener((pool, sampleId, status) -> soundLoaded = status == 0);
        // Плейсхолдер-звук сгенерирован автоматически; замените res/raw/click.wav на свой
        // клик для более приятного звучания — имя ресурса менять не нужно.
        clickSoundId = soundPool.load(this, R.raw.click, 1);
    }

    private void playClick() {
        if (soundEnabled && soundLoaded && soundPool != null && clickSoundId != -1) {
            soundPool.play(clickSoundId, 0.6f, 0.6f, 0, 0, 1f);
        }
    }

    // =================================================================
    // Настройки: акцентный цвет
    // =================================================================

    private void buildAccentSwatches() {
        accentSwatchRow.removeAllViews();
        int sizeDp = 40;
        float density = getResources().getDisplayMetrics().density;
        int sizePx = (int) (sizeDp * density);
        int marginPx = (int) (12 * density);

        for (int color : ACCENT_COLORS) {
            View swatch = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(sizePx, sizePx);
            lp.setMarginEnd(marginPx);
            swatch.setLayoutParams(lp);

            GradientDrawable bg = (GradientDrawable)
                    getResources().getDrawable(R.drawable.swatch_circle).mutate();
            bg.setColor(color);
            bg.setStroke((int) (2 * density), color == accentColor ? 0xFFFFFFFF : 0x00000000);
            swatch.setBackground(bg);

            swatch.setOnClickListener(v -> {
                playClick();
                accentColor = color;
                getPrefs().edit().putInt(PREF_ACCENT_COLOR, color).apply();
                applyAccentColor();
                buildAccentSwatches();
            });

            accentSwatchRow.addView(swatch);
        }
    }

    private void applyAccentColor() {
        android.content.res.ColorStateList tint = android.content.res.ColorStateList.valueOf(accentColor);
        loginButton.setBackgroundTintList(tint);
        loadModuleButton.setBackgroundTintList(tint);
        launchButton.setBackgroundTintList(tint);
    }

    // =================================================================
    // SharedPreferences
    // =================================================================

    private SharedPreferences getPrefs() {
        return getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    private void loadPreferences() {
        SharedPreferences prefs = getPrefs();
        soundEnabled = prefs.getBoolean(PREF_SOUND_ENABLED, true);
        accentColor = prefs.getInt(PREF_ACCENT_COLOR, ACCENT_COLORS[0]);
        soundSwitch.setChecked(soundEnabled);
    }

    private void saveKey(String key) {
        getPrefs().edit().putString(PREF_KEY, key).apply();
    }

    @Nullable
    private String getSavedKey() {
        return getPrefs().getString(PREF_KEY, null);
    }

    // =================================================================
    // Проверка подписи приложения
    // =================================================================

    private void verifyAppSignatureOrDie() {
        // ВРЕМЕННО ОТКЛЮЧЕНО для debug/CI-сборки: EXPECTED_SIGNATURE_SHA256 — заглушка,
        // debug-сборка подписана тестовым ключом и никогда её не пройдёт.
        // Когда сделаешь релизную подписанную сборку — узнаешь реальный SHA-256
        // сертификата и раскомментируешь проверку ниже.
        //
        // String actual = getSigningCertificateSha256();
        // if (actual == null || !actual.equalsIgnoreCase(EXPECTED_SIGNATURE_SHA256)) {
        //     Process.killProcess(Process.myPid());
        //     System.exit(1);
        // }
    }

    @Nullable
    private String getSigningCertificateSha256() {
        try {
            PackageManager pm = getPackageManager();
            String packageName = getPackageName();

            Signature[] signatures;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                PackageInfo info = pm.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES);
                SigningInfo signingInfo = info.signingInfo;
                if (signingInfo == null) return null;
                signatures = signingInfo.hasMultipleSigners()
                        ? signingInfo.getApkContentsSigners()
                        : signingInfo.getSigningCertificateHistory();
            } else {
                @SuppressWarnings("deprecation")
                PackageInfo info = pm.getPackageInfo(packageName, PackageManager.GET_SIGNATURES);
                @SuppressWarnings("deprecation")
                Signature[] sigs = info.signatures;
                signatures = sigs;
            }

            if (signatures == null || signatures.length == 0) return null;

            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(signatures[0].toByteArray());
            return bytesToHex(hash);
        } catch (PackageManager.NameNotFoundException | NoSuchAlgorithmException e) {
            return null;
        }
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format(Locale.US, "%02X", b));
        }
        return sb.toString();
    }

    @Nullable
    private String sha256OfFile(File file) {
        try (FileInputStream fis = new FileInputStream(file)) {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[8192];
            int read;
            while ((read = fis.read(buffer)) != -1) {
                digest.update(buffer, 0, read);
            }
            return bytesToHex(digest.digest());
        } catch (IOException | NoSuchAlgorithmException e) {
            return null;
        }
    }

    private void runOnUi(Runnable r) {
        mainHandler.post(r);
    }
}
