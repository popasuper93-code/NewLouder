# Как этим пользоваться

1. Распакуйте этот zip прямо в корень вашего репозитория на GitHub
   (через "Add file → Upload files", перетащив содержимое, либо `git clone` +
   распаковка + `git add . && git commit && git push`).
2. В корне репозитория должно получиться:
   ```
   .github/workflows/build.yml
   android/settings.gradle
   android/build.gradle
   android/gradle.properties
   android/app/...
   ```
3. Откройте вкладку **Actions** на GitHub — сборка "Build debug APK" стартует
   сама на пуше, либо запустите вручную (Actions → Build debug APK → Run workflow).
4. Когда запуск позеленеет — зайдите в него → внизу **Artifacts** →
   скачайте `app-debug-apk` (внутри будет `app-debug.apk`).

Перед сборкой не забудьте проверить/поправить в
`android/app/src/main/java/com/example/loader/MainActivity.java`:
- `BASE_URL` — адрес вашего сервера лицензий;
- `EXPECTED_SIGNATURE_SHA256` — заполняется после первой сборки и получения
  SHA-256 вашего релизного сертификата (для debug-сборки можно не трогать,
  но тогда проверка подписи будет ронять приложение всегда — либо временно
  закомментируйте вызов `verifyAppSignatureOrDie()` для debug-тестов).
